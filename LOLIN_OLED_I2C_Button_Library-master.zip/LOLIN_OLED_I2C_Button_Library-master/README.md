# Arduino library for the LOLIN OLED Shiled's I2C BUTTON

### Installation
- Clone this repository  or download&unzip [zip file](https://github.com/wemos/LOLIN_OLED_I2C_Button_Library/archive/master.zip) into Arduino/libraries

